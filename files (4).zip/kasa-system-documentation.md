# Kasa — System Documentation

**Twi ⇄ English translator.** Single-file static web app. No build step, no server, no dependencies beyond two external services called at runtime.

- **File:** `kasa-twi-translator.html` (single self-contained file: HTML + CSS + JS + embedded data)
- **Size:** ~88 KB
- **Runtime dependencies:** none (works from `file://`)
- **Network dependencies (optional, only for uncommon phrases):** Google Fonts CDN, MyMemory Translation API
- **License of app code:** none asserted — yours to use. Embedded data has its own attribution requirements (see §6).

---

## 1. What it does

Kasa translates between English and Twi (Akan) in the browser. Every translation request is checked against three tiers, in order, until one produces a result:

| Tier | Source | Coverage | Confidence |
|---|---|---|---|
| 1 | Hand-curated phrasebook | ~90 everyday phrases | Verified — safe to trust |
| 2 | GhanaNLP sentence corpus | 291 human-translated sentences | High — real professional translation, exact match; or transparently-labeled nearest match |
| 3 | MyMemory API | Open vocabulary | Machine translation — Twi is low-resource, treat as a draft |

The UI also exposes the phrasebook as a standalone, browsable reference (6 categories, tap-to-load into the translator), keeps a local history of recent translations, and supports direction-swapping (EN→TW / TW→EN) both for free text and for the corpus/phrasebook lookups.

---

## 2. Architecture

Everything lives in one HTML file, in three blocks:

```
<style>   — design system (CSS custom properties + component styles)
<body>    — markup: nav, hero, translator panes, phrasebook grid, about, footer
<script>  — data (PHRASEBOOK, CORPUS) + logic, wrapped in a single IIFE
```

There is no framework, no bundler, no `import`/`export`. The script is plain ES5-leaning JavaScript (`var`, function expressions) specifically so it runs unmodified in older browsers and needs no transpilation step.

### 2.1 Data flow for a translation request

```
user types text, hits Translate / Enter
        │
        ▼
exactPhraseMatch(text, direction)  ─── hit ──▶ render as "Verified phrase"
        │ miss
        ▼
corpusExactMatch(text, direction)  ─── hit ──▶ render as "GhanaNLP corpus"
        │ miss
        ▼
corpusNearestMatch(text, direction) ── hit ──▶ render as "GhanaNLP corpus"
        │                                      (shows the matched source sentence
        │ miss                                  so the user can judge fit)
        ▼
callMyMemory(text, direction)      ─── hit ──▶ render as "Machine translation"
        │ network failure
        ▼
fuzzyMatches(text, direction)[0]   ─── hit ──▶ render as "Verified phrase"
                                                (degraded fallback)
        │ miss
        ▼
error state: "Couldn't reach the translation service and no
              phrasebook or corpus match was found."
```

This ordering is deliberate: known-good data is always preferred over machine translation, and machine translation is only reached for genuinely open vocabulary.

---

## 3. Data model

### 3.1 `PHRASEBOOK` (object, ~line 405)

```js
var PHRASEBOOK = {
  "Greetings": [
    { en: "Hello", tw: "Ɛte sɛn?", note: "Literally “how is it?” — the everyday greeting." },
    { en: "Good morning", tw: "Maakye" },
    ...
  ],
  "Common phrases": [...],
  "Numbers": [...],
  "Days & time": [...],
  "Family": [...],
  "Food & drink": [...]
};
```

- Keys are category names, used verbatim as tab labels in the phrasebook UI.
- Each entry: `{ en, tw, note? }`. `note` is optional and surfaces both as a card caption and as the status-line message when that phrase is matched.
- ~90 entries total across 6 categories, authored by hand — not sourced from any corpus.
- `flatEntries()` flattens this into `ALL_ENTRIES` at load time for lookup/fuzzy-matching.

### 3.2 `CORPUS` (array, ~line 485)

```js
var CORPUS = [
  { en: "His supporters were very rowdy during the campaign.",
    tw: "N'akyigyinafo yɛɛ basabasa kɛse wɔ ɔsatu no mu." },
  ...
];
```

- Flat array of 291 `{ en, tw }` pairs, no categories.
- Sourced from GhanaNLP's public `ENGLISH_TWI_PARALLEL_TEXT` dataset (Hugging Face) — real, human/professionally translated sentences, not phrasebook-style utility phrases. Covers news, civic life, health, agriculture, etc.
- This is a 291-row sample of GhanaNLP's ~6,090-row published dataset (pulled by paginating their public dataset viewer — see §7 for how to pull more).

---

## 4. Core functions (all inside the single IIFE in `<script>`)

| Function | Purpose |
|---|---|
| `norm(s)` | Lowercase, trim, strip punctuation, collapse whitespace — the shared normalization used by every lookup |
| `flatEntries()` / `ALL_ENTRIES` | Flattens `PHRASEBOOK` into one array for lookup |
| `exactPhraseMatch(text, dir)` | Tier 1 — exact, normalized match against the phrasebook |
| `fuzzyMatches(text, dir, limit)` | Word-overlap scored search against the phrasebook; powers the "You might also mean" suggestion chips and the offline-fallback path |
| `corpusExactMatch(text, dir)` | Tier 2a — exact, normalized match against `CORPUS`, either direction |
| `corpusNearestMatch(text, dir)` | Tier 2b — nearest-neighbour search over `CORPUS` by shared-word overlap. Requires ≥2 shared words *and* ≥60% of the query's meaningful words present in the candidate before it's considered a match; otherwise returns `null` rather than guessing |
| `callMyMemory(text, dir)` | Tier 3 — `fetch()` to the MyMemory API with a 9-second abort timeout; returns a Promise |
| `doTranslate()` | Orchestrates the full tier order in §2.1; the only place that decides which tier wins |
| `renderResult(text, kind)` | Writes the result pane; `kind` is `"verified"` \| `"corpus"` \| `"machine"` \| `null`, drives the badge shown via the `BADGES` lookup table |
| `renderSuggestions(text, dir)` | Populates the "You might also mean" chips from `fuzzyMatches` |
| `pushHistory(src, tgt, dir)` / `renderHistory()` | Maintains a max-10-item recent-translations list, persisted to `localStorage` under key `kasa-history` (wrapped in try/catch — degrades silently if storage is unavailable, e.g. private browsing) |
| `renderTabs()` / `renderGrid()` | Draws the phrasebook category tabs and phrase-card grid |
| `escapeHtml(s)` | Manual HTML-escaping for any user-influenced string written via `innerHTML` |

### 4.1 Event wiring (bottom of the script)

- `translateBtn` click, and `Enter` (without Shift) in the textarea → `doTranslate()`
- `clearBtn` → resets input/output/status
- `swapBtn` → flips `direction`, updates labels, re-runs translation on the swapped text if present, rotates the icon (`.spin` class) — animation respects `prefers-reduced-motion`
- `copyBtn` → `navigator.clipboard.writeText`, with a manual `document.execCommand("copy")` fallback for older browsers
- Phrase card click → loads the phrase into the translator, forces `direction = "en-tw"`, scrolls to top
- History chip click → restores that translation's direction, input, and re-translates

---

## 5. Design system

Grounded in Akan visual language rather than generic app styling.

**Color tokens** (`:root` custom properties):
| Token | Hex | Use |
|---|---|---|
| `--void` | `#15100c` | Page background |
| `--surface` / `--surface-2` | `#1e1710` / `#261c13` | Cards, panes |
| `--hairline` | `#3a2c1d` | Borders |
| `--gold` / `--gold-soft` | `#cc9a3d` / `#e8c877` | Primary accent, "machine translation" badge |
| `--rust` | `#b3492f` | "GhanaNLP corpus" badge |
| `--green` | `#3d6b52` | (referenced for verified-state accents) |
| `--bone` / `--bone-dim` / `--bone-faint` | `#f2e8d5` / `#b9a98c` / `#8a7c63` | Text, in descending emphasis |

**Typography:**
- Display: `Fraunces` (headlines, wordmark)
- Body/UI: `Manrope`, falling back to `Noto Sans` for full Twi-diacritic coverage (ɛ, ɔ, and combining marks)
- Data/labels: `IBM Plex Mono` (language tags, eyebrows, keyboard hints)

**Signature motif:** a hand-drawn Sankofa-bird SVG (the Adinkra symbol for "go back and fetch it") — used in the nav mark, as a faint hero watermark, and conceptually as the swap-direction icon (rotates 180° on click).

**Layout:** two-pane translator (source / target) with a circular swap button between them, a five-band "kente rule" (`repeating-linear-gradient`) as a section divider, and a card grid for the phrasebook. Responsive: panes stack vertically under 760px.

---

## 6. Data sources, licensing & attribution

| Source | License / terms | Attribution given in-app |
|---|---|---|
| Phrasebook (~90 entries) | Original — hand-authored for this project | — |
| GhanaNLP corpus (291 entries) | GhanaNLP's data card mixes a CC BY 4.0 link with Non-Commercial / Share-Alike terms elsewhere on the same page. **Treated here as CC BY-NC-SA** (the stricter reading) until GhanaNLP clarifies. **Do not use commercially without confirming with GhanaNLP directly.** | Linked and credited in the "About" section and footer |
| MyMemory Translation API | Free community-edited translation memory; used via public, unauthenticated `GET` requests | Named in-app as the machine-translation source |

**JW300 was deliberately excluded.** An earlier request to add the JW300 English–Twi corpus (via Kaggle) was declined: JW300 was pulled from public distribution around 2021 after a copyright dispute (the Watch Tower Society's terms of use prohibit bulk text/data mining of their material), and Masakhane — the research group that built the original corpus — discontinued its own use of it for that reason. GhanaNLP's dataset was sourced instead as a clean, legitimately licensed replacement.

---

## 7. Known limitations

- **Corpus is a 291-row sample, not the full dataset.** GhanaNLP's published set has ~6,090 rows; only 291 were pulled (by paginating their public Hugging Face dataset viewer, since Kaggle/Mendeley-style bulk API access wasn't reachable from the pulling environment). To extend: fetch more pages from `https://huggingface.co/datasets/Ghana-NLP/ENGLISH_TWI_PARALLEL_TEXT/viewer/default/train?p=N` and append `{en, tw}` objects to the `CORPUS` array.
- **`corpusNearestMatch` is a real-sentence lookup, not a sentence-level translator.** It cannot combine or generalize — it only ever returns a sentence that already exists verbatim in the corpus. Off-corpus phrasing falls through to MyMemory.
- **MyMemory quality for Twi is inconsistent.** Twi is low-resource for MT; the app labels machine-translation output explicitly so this is never mistaken for a verified translation.
- **History and no other state persists.** Only the last-10 translation history uses `localStorage`; there's no accounts, sync, or server-side storage — everything else is in-memory and resets on reload.
- **No audio/pronunciation.** Browser `SpeechSynthesis` doesn't reliably support Twi voices, so this was intentionally left out rather than shipped broken.

---

## 8. Testing performed

- **JS syntax:** validated with `node --check` against the extracted `<script>` contents after every edit.
- **HTML structural integrity:** open/close tag-count balance checked programmatically for `div`, `section`, `header`, `nav`, `footer`, `main`, `button`, `textarea`.
- **Matching logic:** the lookup functions (`exactPhraseMatch`, `corpusExactMatch`, `corpusNearestMatch`) were extracted and run directly in Node against known cases:
  - Exact phrasebook match ("thank you" → "Medaase")
  - Exact corpus match (full sentence, both directions EN→TW and TW→EN)
  - Correct nearest-match on a near-paraphrase of a corpus sentence
  - Correct `null` (no match) on unrelated text
- **No automated browser/visual test suite exists.** Manual review only; no headless-browser screenshot tooling was available in the build environment.

---

## 9. Deployment

No build step. Any static host works:

- **Netlify Drop:** drag `kasa-twi-translator.html` onto app.netlify.com/drop, renamed to `index.html`. Live URL in seconds, no account.
- **GitHub Pages:** commit the file as `index.html`, enable Pages on the repo in Settings.
- **Vercel:** `npx vercel` from the containing folder, or drag-and-drop in the dashboard.

Opening the file directly (`file://`) also works fully — the phrasebook and corpus tiers are entirely client-side; only the MyMemory fallback needs network access.

---

## 10. File map (single file — line numbers as of this version)

| Lines (~) | Contents |
|---|---|
| 1–20 | `<head>`, meta, Google Fonts links |
| ~20–260 | `<style>` — design tokens and component CSS |
| ~260–398 | `<body>` markup |
| 398 | `(function(){ "use strict";` — start of app IIFE |
| 405–466 | `PHRASEBOOK` data |
| 485 | `CORPUS` data (291 entries, inline JSON-literal array) |
| 490–517 | State + DOM element references |
| 520–597 | Lookup/matching functions (§4) |
| 599–719 | Render/UI-update functions |
| 721–775 | `doTranslate()` |
| 786–825 | Phrasebook tab/grid rendering |
| 827–884 | Event wiring |
| 887–893 | Init calls, closing `})();`, `</script>`, `</body>`, `</html>` |

---

## 11. Change log

- **v1** — Two-tier system: hand-curated phrasebook + MyMemory fallback. Akan/Sankofa visual identity established.
- **v2** — Added GhanaNLP corpus as a middle tier (exact + nearest-match), with transparent labeling and attribution. Declined to add JW300 for copyright reasons (see §6). Fixed a leftover `verified: false` initial state to match the new three-way `kind` field on `lastResult`.
